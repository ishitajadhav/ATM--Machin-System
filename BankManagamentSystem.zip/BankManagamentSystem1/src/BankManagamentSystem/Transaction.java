package BankManagamentSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Transaction  extends JFrame implements ActionListener {
    JButton deposit,cashwidrowle,fastcash,pinchange,balanceenquery,exit;
    String pinno;
    Transaction(String pinno){
        this.pinno=pinno;

        setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/icon2.png"));
        Image i2 = i1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(10,10,900,900);
        add(image);

        deposit = new JButton("Deposit");
        deposit.setBounds(200,290,140,30);
        deposit.addActionListener(this);
        image.add(deposit);

        fastcash = new JButton("Fast Cash");
        fastcash.setBounds(350,290,140,30);
        fastcash.addActionListener(this);
        image.add(fastcash);

        cashwidrowle = new JButton("Cash Withdraw");
        cashwidrowle.setBounds(200,340,140,30);
        cashwidrowle.addActionListener(this);
        image.add(cashwidrowle);

        pinchange= new JButton("PIN Change");
        pinchange.setBounds(350,340,140,30);
        pinchange.addActionListener(this);
        image.add(pinchange);

        balanceenquery= new JButton("Balance Enquiry");
        balanceenquery.setBounds(280,390,140,30);
        balanceenquery.addActionListener(this);
        image.add(balanceenquery);

        exit= new JButton("EXIT");
        exit.setBounds(400,450,80,20);
        exit.setFont(new Font("System",Font.BOLD,10));
        exit.addActionListener(this);
        image.add(exit);

        setSize(900,900);
        setLocation(300,0);
        getContentPane().setBackground(Color.black);
        setUndecorated(true);
        setVisible(true);

    }public void actionPerformed(ActionEvent ae) {

        if(ae.getSource()==exit){
            System.exit(0);
        } else if (ae.getSource()==deposit) {
            setVisible(false);
            new Deposit(pinno).setVisible(true);
        } else if (ae.getSource()==cashwidrowle) {
            setVisible(false);
            new Withdrawal(pinno).setVisible(true);
        } else if (ae.getSource()==fastcash) {
            setVisible(false);
            new FastTransaction(pinno).setVisible(true);
        } else if (ae.getSource()==balanceenquery) {
            setVisible(false);
            new Balance(pinno).setVisible(true);
        } else if (ae.getSource()==pinchange) {
            new ChangePin(pinno).setVisible(true);
        }
    }

    public static void  main (String[]args){

    new Transaction("");
    }
}
