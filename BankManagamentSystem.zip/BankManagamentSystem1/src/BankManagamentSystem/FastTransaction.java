package BankManagamentSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Date;

public class  FastTransaction  extends JFrame implements ActionListener {
    JButton onehundred,fivehundred,onethousand,twothousand,fivethousand,tenthousand,exit;
    String pinno;
    FastTransaction(String pinno){
        this.pinno=pinno;

        setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/icon2.png"));
        Image i2 = i1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(10,10,900,900);
        add(image);

        onehundred = new JButton("RS 100 ");
        onehundred.setBounds(200,290,140,30);
        onehundred.addActionListener(this);
        image.add(onehundred);

        fivehundred = new JButton("RS 500 ");
        fivehundred.setBounds(350,290,140,30);
        fivehundred.addActionListener(this);
        image.add(fivehundred);

        onethousand = new JButton("RS 1000 ");
        onethousand.setBounds(200,340,140,30);
        onethousand.addActionListener(this);
        image.add(onethousand);

        twothousand= new JButton("RS 2000 ");
        twothousand.setBounds(350,340,140,30);
        twothousand.addActionListener(this);
        image.add(twothousand);

        fivethousand= new JButton("RS 5000 ");
        fivethousand.setBounds(200,400,140,30);
        fivethousand.addActionListener(this);
        image.add(fivethousand);

        tenthousand= new JButton("RS 10000 ");
        tenthousand.setBounds(350,400,140,30);
        tenthousand.addActionListener(this);
        image.add(tenthousand);

        exit= new JButton("EXIT");
        exit.setBounds(380,450,100,30);
        exit.addActionListener(this);
        image.add(exit);

        setSize(900,900);
        setLocation(300,0);
        getContentPane().setBackground(Color.black);
        setUndecorated(true);
        setVisible(true);

    }public void actionPerformed(ActionEvent ae) {
        if(ae.getSource()==exit){
            System.exit(0);
        } else {
            String amount = ((JButton) ae.getSource()).getText().substring(3).trim();
            System.out.println(amount);
            try {
                Conn conn = new Conn();
                ResultSet rs = conn.s.executeQuery("select * from bank where pinnumber = "+pinno+" " );
                int balance = 0;
                while (rs.next()) {
                    String transactionType = rs.getString("type");
                    int transactionAmount = Integer.parseInt(rs.getString("amount").trim());
                    if (transactionType.equals("Deposit")) {
                        balance += transactionAmount;
                    } else {
                        balance -= transactionAmount;
                    }
                }
                if (ae.getSource() != exit && balance < Integer.parseInt(amount)){
                    JOptionPane.showMessageDialog(null, "Insufficient Balance");
                    return;
                }
                Date date = new Date();
                String query = "insert into bank values('"+pinno+"' , '"+date+"' , 'withdrawal' , '"+amount+" '  )";
                conn.s.executeUpdate(query);
                JOptionPane.showMessageDialog(null,"RS " +amount+ " Debited successfully");

                setVisible(false);
                new Transaction(pinno).setVisible(true);
            }catch(Exception e){
                    System.out.println(e);
                }
            }
        }
    public static void  main (String[]args){

        new Transaction("");
    }
}

