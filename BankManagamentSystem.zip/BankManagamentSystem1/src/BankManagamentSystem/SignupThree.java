package BankManagamentSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.*;
import java.util.Random;

public class SignupThree extends JFrame implements ActionListener {
    JRadioButton r1,r2,r3,r4;
    JCheckBox c1,c2,c3,c4,c5,c6,c7;
    JButton submit,cancel;
    String formno;

    SignupThree(String formno){
        this.formno = formno;

        setLayout(null);
        JLabel l1 = new JLabel("Page 3 : Account Details ");
        l1.setFont(new Font("Raleway",Font.BOLD,25));
        l1.setForeground(Color.white);
        l1.setBounds(250,40,400,40);
        add(l1);

        JLabel accounttype = new JLabel(" Account Type:");
        accounttype.setFont(new Font("Raleway",Font.BOLD,20));
        accounttype.setForeground(Color.white);
        accounttype.setBounds(100,140,200,30);
        add(accounttype);
        r1 = new JRadioButton(" Saving Account ");
        r1.setBounds(100,180,170,20);
        r1.setFont(new Font("Raleway",Font.BOLD,12));
        r1.setForeground(Color.white);
        r1.setBackground(Color.black);
        add(r1);

        r2 = new JRadioButton(" Fixed Deposit Account ");
        r2.setBounds(350,180,250,20);
        r2.setFont(new Font("Raleway",Font.BOLD,12));
        r2.setForeground(Color.white);
        r2.setBackground(Color.black);
        add(r2);

        r3 = new JRadioButton(" Current Account ");
        r3.setBounds(100,220,170,20);
        r3.setFont(new Font("Raleway",Font.BOLD,12));
        r3.setForeground(Color.white);
        r3.setBackground(Color.black);
        add(r3);

        r4 = new JRadioButton(" Recurring Deposit Account ");
        r4.setBounds(350,220,250,20);
        r4.setFont(new Font("Raleway",Font.BOLD,12));
        r4.setForeground(Color.white);
        r4.setBackground(Color.black);
        add(r4);

        ButtonGroup bu = new ButtonGroup();
        bu.add(r1);
        bu.add(r2);
        bu.add(r3);
        bu.add(r4);

        JLabel cardno = new JLabel(" Card Number:");
        cardno.setFont(new Font("Raleway",Font.BOLD,25));
        cardno.setForeground(Color.white);
        cardno.setBounds(100,300,200,30);
        add(cardno);

        JLabel number = new JLabel(" xxxx-xxxx-xxxx-4142 ");
        number.setFont(new Font("Raleway",Font.BOLD,22));
        number.setForeground(Color.white);
        number.setBounds(330,300,270,30);
        add(number);
        JLabel carddetail = new JLabel("  Your 16 Digit Card Number ");
        carddetail.setFont(new Font("Raleway",Font.BOLD,11));
        carddetail.setForeground(Color.white);
        carddetail.setBounds(110,330,180,20);
        add(carddetail);

        JLabel pin = new JLabel(" PIN Number:");
        pin.setFont(new Font("Raleway",Font.BOLD,25));
        pin.setForeground(Color.white);
        pin.setBounds(100,370,200,30);
        add(pin);
        JLabel pinno = new JLabel(" xxxx ");
        pinno.setFont(new Font("Raleway",Font.BOLD,22));
        pinno.setForeground(Color.white);
        pinno.setBounds(330,370,250,30);
        add(pinno);
        JLabel pinddetail = new JLabel("  Your 4 Digit PIN Number ");
        pinddetail.setFont(new Font("Raleway",Font.BOLD,11));
        pinddetail.setForeground(Color.white);
        pinddetail.setBounds(110,400,180,20);
        add(pinddetail);

        JLabel service = new JLabel(" Service Required ");
        service.setFont(new Font("Raleway",Font.BOLD,22));
        service.setForeground(Color.white);
        service.setBounds(110,450,200,20);
        add(service);

        c1 = new JCheckBox("ATM Card");
        c1.setFont(new Font("Raleway",Font.BOLD,14));
        c1.setBounds(100,500,150,30);
        c1.setForeground(Color.white);
        c1.setBackground(Color.black);
        add(c1);

        c2 = new JCheckBox("Internet Banking");
        c2.setFont(new Font("Raleway",Font.BOLD,14));
        c2.setBounds(285,500,150,30);
        c2.setForeground(Color.white);
        c2.setBackground(Color.black);
        add(c2);

        c3 = new JCheckBox("Mobile Banking");
        c3.setFont(new Font("Raleway",Font.BOLD,12));
        c3.setBounds(465,500,150,30);
        c3.setForeground(Color.white);
        c3.setBackground(Color.black);
        add(c3);

        c4 = new JCheckBox("Email & SMS Alerts");
        c4.setFont(new Font("Raleway",Font.BOLD,12));
        c4.setBounds(100,550,150,30);
        c4.setForeground(Color.white);
        c4.setBackground(Color.black);
        add(c4);

        c5 = new JCheckBox("Cheque Book");
        c5.setFont(new Font("Raleway",Font.BOLD,12));
        c5.setBounds(285,550,150,30);
        c5.setForeground(Color.white);
        c5.setBackground(Color.black);
        add(c5);

        c6 = new JCheckBox("E-Statement");
        c6.setFont(new Font("Raleway",Font.BOLD,12));
        c6.setBounds(465,550,150,30);
        c6.setForeground(Color.white);
        c6.setBackground(Color.black);
        add(c6);

        c7 = new JCheckBox("I Here Declares that the above entered details are correct to the my best of knowledge");
        c7.setFont(new Font("Raleway",Font.BOLD,12));
        c7.setBounds(100,640,520,30);
        c7.setForeground(Color.white);
        c7.setBackground(Color.black);
        add(c7);

        submit = new JButton("SUBMIT");
        submit.setBounds(150,680,150,30);
        submit.setFont(new Font("Raleway",Font.BOLD,16));
        submit.setBackground(Color.white);
        submit.setForeground(Color.black);
        submit.addActionListener(this);
        add(submit);

        cancel = new JButton("Cancel");
        cancel.setBounds(430,680,150,30);
        cancel.setFont(new Font("Raleway",Font.BOLD,16));
        cancel.setBackground(Color.white);
        cancel.setForeground(Color.black);
        cancel.addActionListener(this);
        add(cancel);

        setSize(850,820);
        getContentPane().setBackground(Color.black);
        setLocation(350,0);
        setVisible(true);
    }
    public void actionPerformed (ActionEvent ae) {
        if(ae.getSource()==submit) {
            String accounttype = null;

            if (r1.isSelected()) {
                accounttype = " Saving Account";
            } else if ((r2.isSelected())) {
                accounttype = "Fixed Deposit Account";
            } else if (r3.isSelected()) {
                accounttype = " Current Account ";
            } else if (r4.isSelected()) {
                accounttype = "Recurring Deposit Account";
            }

            Random random = new Random();
            String cardnumber = " " + Math.abs((random.nextLong() % 90000000L) + 5040936000000000L);

            String pinnumber = " " + Math.abs((random.nextLong() % 9000L ) + 1000L);

            String facility = getString();

            try {
                if (accounttype.equals(" ")){
                    JOptionPane.showMessageDialog(null,"Account type is required");
                }
                else {
                    Conn conn = new Conn();
                    String query1 = "insert into signupThree values('" + formno + "', '" + accounttype + "' , '" + cardnumber + "' , '" + pinnumber + "' , '" + facility + "' )";
                    conn.s.executeUpdate(query1);
                    String query2 = "insert into login values('" + formno + "' , '" + cardnumber + "' , '" + pinnumber + "' )";
                    JOptionPane.showMessageDialog(null,"Card Number" + cardnumber + "\n PIN Number" + pinnumber );
                    conn.s.executeUpdate(query2);
                }
            }catch (Exception e){
                System.out.println(e);
            }
        }
            else if (ae.getSource()==cancel) {
                System.exit(0);
            }
    }
         String getString() {
        String facility = " ";
        if (c1.isSelected()) {
            facility = facility + "ATM Card";
        } else if (c2.isSelected()) {
            facility = facility + "Internet Banking";
        } else if (c3.isSelected()) {
            facility = facility + "Mobile Banking";
        } else if (c4.isSelected()) {
            facility = facility + "Email & SMS Alerts";
        } else if (c5.isSelected()) {
            facility = facility + "Cheque Book";
        } else if (c6.isSelected()) {
            facility = facility + "E-Statement";
        }
        return facility;
    }

    public static void main(String[]args){
        new SignupThree(" ");
    }
}
