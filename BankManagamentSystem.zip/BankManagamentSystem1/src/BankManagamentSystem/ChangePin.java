package BankManagamentSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class ChangePin extends JFrame implements ActionListener {

    JLabel text,  npin,repin;
    JTextField changeTextfield,rpinTextfiedl;
    JButton change,exit;
    String pinno;
    ChangePin(String pinno){
        this.pinno = pinno;

        setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/icon2.png"));
        Image i2 = i1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(10,10,900,900);
        add(image);

        text = new JLabel("Change your PIN number");
        text.setBounds(210,290,300,30);
        text.setFont(new Font("Raleway",Font.BOLD,18));
        text.setForeground(Color.black);
        image.add(text);

        npin = new JLabel("Enter new pin");
        npin.setBounds(200,350,130,20);
        npin.setFont(new Font("Raleway",Font.BOLD,14));
        image.add(npin);
        changeTextfield = new JTextField();
        changeTextfield.setBounds(380,350,100,20);
        changeTextfield.addActionListener(this);
        image.add(changeTextfield);



        repin = new JLabel("Re-Enter PIN:");
        repin.setBounds(200,380,130,20);
        repin.setFont(new Font("Raleway",Font.BOLD,14));
        repin.setForeground(Color.black);
        image.add(repin);
        rpinTextfiedl = new JTextField();
        rpinTextfiedl.setBounds(380,380,100,20);
        image.add(rpinTextfiedl);

        change = new JButton("Change PIN");
        change.setBounds(370,425,100,25);
        change.setFont(new Font("System",Font.BOLD,10));
        change.addActionListener(this);
        image.add(change);

        exit = new JButton("Back");
        exit.setBounds(370,455,100,25);
        exit.setFont(new Font("System",Font.BOLD,10));
        exit.addActionListener(this);
        image.add(exit);

        setSize(900,900);
        setLocation(300,0);
        getContentPane().setBackground(Color.black);
        setVisible(true);

    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == change) {
            try {

                String newpin = changeTextfield.getText();
                System.out.println(newpin);
                String rpin = rpinTextfiedl.getText();
                System.out.println(rpin);

                if (newpin.equals(rpin)) {
                    Conn conn = new Conn();

                    String query1 = "update bank set pinnumber ="+newpin+"  where pinnumber = "+pinno+" ";
                    System.out.println(query1);
                    String query2 = "update login  set pinumber ="+newpin+"  where pinumber = "+pinno+" ";
                    System.out.println(query2);
                    String query3 = "update signupThree set pinnumber ="+newpin+"  where pinnumber = "+pinno+" ";
                    System.out.println(query3);

                    conn.s.executeUpdate(query1);
                    System.out.println("entered1");
                    conn.s.executeUpdate(query2);
                    System.out.println("entered2");
                    conn.s.executeUpdate(query3);
                    System.out.println("entered3");


                    JOptionPane.showMessageDialog(null, "PIN change successfully");

                    setVisible(false);
                    new Transaction(newpin).setVisible(true);
                }else {
                        JOptionPane.showMessageDialog(null, "Entered PIN does not match");
                    if (newpin.equals("")) {
                        JOptionPane.showMessageDialog(null,"Please enter new PIN");
                    }
                    if (rpin.equals("")) {
                        JOptionPane.showMessageDialog(null,"Please enter re-entered");
                    }
                }

            } catch (Exception e) {
                System.out.println(e);
            }

        }else {
            setVisible(false);
            new Transaction(pinno).setVisible(true);
        }
    }

    public static void main(String[]args){
        new ChangePin("");
    }
}
