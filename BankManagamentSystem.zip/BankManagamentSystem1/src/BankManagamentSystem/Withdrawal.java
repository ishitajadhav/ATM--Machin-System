package BankManagamentSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

public class Withdrawal  extends JFrame implements ActionListener {
        JLabel with;
        JTextField amount;
        JButton withdrawal,exit;
        String pinno;
        Withdrawal(String pinno){
            this.pinno = pinno;

            setLayout(null);
            ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/icon2.png"));
            Image i2 = i1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
            ImageIcon i3 = new ImageIcon(i2);
            JLabel image = new JLabel(i3);
            image.setBounds(10,10,900,900);
            add(image);

            with = new JLabel("Enter the amount you want to Withdrawal ");
            with.setBounds(210,290,280,20);
            with.setFont(new Font("Raleway",Font.BOLD,14));
            with.setForeground(Color.black);
            image.add(with);

            amount =new JTextField();
            amount.setBounds(210,320,250,20);
            amount.setFont(new Font("Arial",Font.BOLD,13));
            image.add(amount);

             withdrawal= new JButton("Withdrawal");
            withdrawal.setBounds(380,420,100,25);
            withdrawal.addActionListener(this);
            image.add(withdrawal);

            exit = new JButton("Back");
            exit.setBounds(380,450,100,25);
            exit.addActionListener(this);
            image.add(exit);

            setSize(900,900);
            setLocation(350,0);
            getContentPane().setBackground(Color.black);
            setVisible(true);
        }
        public void actionPerformed(ActionEvent ae){
            if (ae.getSource()==withdrawal){
                String number = amount.getText();
                String wid = withdrawal.getText();
                Date date = new Date();
                if (number.equals("")){
                    JOptionPane.showMessageDialog(null,"Please enter amount you want to withdrawal");
                }
                try {
                    Conn conn = new Conn();
                    String query = "insert into bank values('" +pinno+ "', '" +date+ "' , '" +wid+ "' , ' "+number+ "')";
                    conn.s.executeUpdate(query);
                    JOptionPane.showMessageDialog(null,"RS"+wid+"Withdrawal successful");
                    setVisible(false);
                    new Transaction(pinno).setVisible(true);
                }catch (Exception e){
                    System.out.println(e);
                }
            } else if (ae.getSource()==exit) {
                setVisible(false);
                new Transaction(pinno).setVisible(true);
            }
        }
        public static void main (String[]args){

            new Withdrawal(" ");
        }
    }


