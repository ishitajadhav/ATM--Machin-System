package BankManagamentSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Balance extends JFrame implements ActionListener{
    String pinno;
    JLabel text;
    JButton exit;

    Balance(String pinno){
        this.pinno = pinno;

        setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/icon2.png"));
        Image i2 = i1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(10,10,900,900);
        add(image);

        exit = new JButton("BACK");
        exit.setBounds(400,460,80,25);
        exit.addActionListener(this);
        image.add(exit);

        setSize(900,900);
        setLocation(300,0);
        getContentPane().setBackground(Color.black);
        setVisible(true);

        Conn conn = new Conn();
        int balance = 0;
            try {
                ResultSet rs = conn.s.executeQuery("select * from bank where pinnumber = "+pinno+" " );
                while (rs.next()) {
                    String transactionType = rs.getString("type");
                    int transactionAmount = Integer.parseInt(rs.getString("amount").trim());
                    if (transactionType.equals("Deposit")) {
                        balance += transactionAmount;
                    } else {
                        balance -= transactionAmount;
                    }
                }
            }catch(Exception e){
                System.out.println(e);
            }
        text = new JLabel("Your current balance "+balance+" is");
        text.setBounds(250,300,300,20);
        text.setFont(new Font("Raleway",Font.BOLD,16));
        image.add(text);
    }
    public void actionPerformed(ActionEvent ae){
        if (ae.getSource()==exit){
         setVisible(false);
         new Transaction(pinno).setVisible(true);
        }
        }
    public static void main(String[]args){
        new Balance("");
    }
}
