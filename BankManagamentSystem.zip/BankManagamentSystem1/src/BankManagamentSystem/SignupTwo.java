package BankManagamentSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class SignupTwo extends JFrame implements ActionListener {

    JTextField aadharTextField,panTextField;
    JButton next;
    JRadioButton eyes,eno,sno,syes;
    JComboBox jreligion,jcategory,jincome,jeducation,joccupation;
    String formno;
    SignupTwo(String formno) {
        this.formno = formno;

        setLayout(null);
        JLabel additionaldetail = new JLabel("Page 2: Additional Details : ");
        additionaldetail.setForeground(Color.WHITE);
        additionaldetail.setFont(new Font("Raleway", Font.BOLD, 30));
        additionaldetail.setBounds(240, 45, 400, 80);
        add(additionaldetail);

        JLabel religion = new JLabel("Religion:");
        religion.setForeground(Color.WHITE);
        religion.setFont(new Font("Raleway", Font.BOLD, 22));
        religion.setBounds(100, 140, 200, 30);
        add(religion);
        String valreligion[]={"HINDU","MUSLIN","SHIKH","CRITCHAN","BUADH","PARSHI","+OTHER"};
        jreligion =  new JComboBox(valreligion);
        jreligion.setBackground(Color.WHITE);
        jreligion.setBounds(300, 140, 400, 30);
        add(jreligion);

        JLabel category = new JLabel("Category : ");
        category.setForeground(Color.WHITE);
        category.setFont(new Font("Raleway", Font.BOLD, 22));
        category.setBounds(100, 190, 200, 30);
        add(category);
        String valcategory[] =  {"General","OBC","SC","ST","Other"};
        jcategory = new JComboBox(valcategory);
        jcategory.setBounds(300, 190, 400, 30);
        add(jcategory);

        JLabel income = new JLabel("Income:");
        income.setForeground(Color.WHITE);
        income.setFont(new Font("Raleway", Font.BOLD, 22));
        income.setBounds(100, 240, 200, 30);
        add(income);
        String valincome[] =  {"NULL","<150000","<250000","<500000","UPTO 1000000"};
        jincome = new JComboBox(valincome);
        jincome.setBounds(300, 240, 400, 30);
        add(jincome);

        JLabel education = new JLabel("Educational:");
        education.setForeground(Color.WHITE);
        education.setFont(new Font("Raleway", Font.BOLD, 22));
        education.setBounds(100, 290, 200, 30);
        add(education);
        String valeducationvaluses[] =  {"Non-Graduate","Graduate","Post-Graduate","Doctor","Other"};
        jeducation = new JComboBox(valeducationvaluses);
        jeducation.setBounds(300, 300, 400, 30);
        add(jeducation);

        JLabel qualification = new JLabel("Qualification:");
        qualification.setForeground(Color.WHITE);
        qualification.setFont(new Font("Raleway", Font.BOLD, 22));
        qualification.setBounds(100, 315, 200, 30);
        add(qualification);

        JLabel occupation = new JLabel("Occupation:");
        occupation.setForeground(Color.WHITE);
        occupation.setFont(new Font("Raleway", Font.BOLD, 22));
        occupation.setBounds(100, 390, 200, 30);
        add(occupation);
        String valoccupation[] =  {"Salaried","Self-Employed","Business","Student","Retired","Other"};
        joccupation = new JComboBox(valoccupation);
        joccupation.setBounds(300, 390, 400, 30);
        add(joccupation);

        JLabel pan = new JLabel("Pan No:");
        pan.setForeground(Color.WHITE);
        pan.setFont(new Font("Raleway", Font.BOLD, 22));
        pan.setBounds(100, 440, 200, 30);
        add(pan);
        panTextField = new JTextField();
        panTextField.setFont(new Font("Raleway", Font.BOLD, 14));
        panTextField.setBounds(300, 440, 400, 30);
        add(panTextField);

        JLabel Address = new JLabel("Aadhar No :");
        Address.setForeground(Color.WHITE);
        Address.setFont(new Font("Raleway", Font.BOLD, 22));
        Address.setBounds(100, 490, 200, 30);
        add(Address);
         aadharTextField = new JTextField();
        aadharTextField.setFont(new Font("Raleway", Font.BOLD, 14));
        aadharTextField.setBounds(300, 490, 400, 30);
        add(aadharTextField);

        JLabel senior = new JLabel("Senior Citizen:");
        senior.setForeground(Color.WHITE);
        senior.setFont(new Font("Raleway", Font.BOLD, 22));
        senior.setBounds(100, 540, 200, 30);
        add(senior);
        sno =  new JRadioButton("No");
        sno.setBounds(630, 540, 70, 30);
        add(sno);
        syes =  new JRadioButton("YEN");
        syes.setBounds(300, 540, 70, 30);
        add(syes);
        ButtonGroup butn = new ButtonGroup();
        butn.add(sno);
        butn.add(syes);

        JLabel exaccount = new JLabel("Existing Account:");
        exaccount.setForeground(Color.WHITE);
        exaccount.setFont(new Font("Raleway", Font.BOLD, 22));
        exaccount.setBounds(100, 590, 200, 30);
        add(exaccount);
        eno =  new JRadioButton("No");
        eno.setBounds(630, 590, 70, 30);
        add(eno);
        eyes =  new JRadioButton("Yes");
        eyes.setBounds(300, 590, 70, 30);
        add(eyes);
        ButtonGroup but = new ButtonGroup();
        but.add(eyes);
        but.add(eno);

        next = new JButton(" NEXT");
        next.setBackground(Color.black);
        next.setForeground(Color.white);
        next.setFont(new Font("Raleway", Font.BOLD, 14));
        next.setBounds(620, 660, 80, 30);
        next.addActionListener(this);
        add(next);

        setSize(850, 800);
        setLocation(350, 10);
        getContentPane().setBackground(Color.black);
        setVisible(true);

    }
       public void actionPerformed (ActionEvent ae) {
           String religion = (String)jreligion.getSelectedItem();
           String category =  (String) jcategory.getSelectedItem();
           String income =  (String)jincome.getSelectedItem();
           String education = (String) jeducation.getSelectedItem();
           String occupation =  (String) joccupation.getSelectedItem();

           String sin = null;
           if (sno.isSelected()) {
               sin = "No";
           } else if (syes.isSelected()) {
               sin = "YES";
           }

           String acco = null;
           if (eno.isSelected()) {
               acco = "NO";
           } else if (eyes.isSelected()) {
               acco = "Yes";
           }

           String aadhar = aadharTextField.getText();
           String pan = panTextField.getText();

           try {
                   Conn co = new Conn();
                   String query = "insert into signuptow values( '"+formno+"' ,'" + religion + "' ,'" + category + "' , '" + income + "' , '" + education + "' , '" + occupation + "' " +
                           ", '" +sin+ "' , '" +acco+ "' , '" +aadhar+ "' , '" +pan+ "' )";
                   co.s.executeUpdate(query);
               setVisible(false);
               new SignupThree(formno).setVisible(true );
           } catch (Exception e) {
               System.out.println(e);
           }
       }

    public static void main(String[]args){
        new SignupTwo(" ");
    }
    }



